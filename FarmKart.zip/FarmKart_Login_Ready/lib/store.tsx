"use client"

import React, { createContext, useContext, useState, useCallback, useEffect } from "react"
import type { CartItem, Product, Order } from "./data"

// --- Cart Context ---
interface CartContextType {
  items: CartItem[]
  addToCart: (product: Product) => void
  removeFromCart: (productId: string) => void
  updateQuantity: (productId: string, quantity: number) => void
  clearCart: () => void
  totalItems: number
  totalPrice: number
}

const CartContext = createContext<CartContextType | undefined>(undefined)

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([])

  const addToCart = useCallback((product: Product) => {
    setItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id)
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      }
      return [...prev, { product, quantity: 1 }]
    })
  }, [])

  const removeFromCart = useCallback((productId: string) => {
    setItems((prev) => prev.filter((item) => item.product.id !== productId))
  }, [])

  const updateQuantity = useCallback((productId: string, quantity: number) => {
    if (quantity <= 0) {
      setItems((prev) => prev.filter((item) => item.product.id !== productId))
      return
    }
    setItems((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    )
  }, [])

  const clearCart = useCallback(() => setItems([]), [])

  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0)
  const totalPrice = items.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  )

  return (
    <CartContext.Provider
      value={{
        items,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        totalItems,
        totalPrice,
      }}
    >
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  const context = useContext(CartContext)
  if (!context) throw new Error("useCart must be used within CartProvider")
  return context
}

// --- Order Context ---
interface OrderContextType {
  orders: Order[]
  addOrder: (order: Order) => void
}

const OrderContext = createContext<OrderContextType | undefined>(undefined)

export function OrderProvider({ children }: { children: React.ReactNode }) {
  const [orders, setOrders] = useState<Order[]>([
    {
      id: "ORD-2024-001",
      type: "product",
      items: [
        { name: "Hybrid Wheat Seeds", quantity: 3, price: 450 },
        { name: "DAP Fertilizer", quantity: 1, price: 1350 },
      ],
      total: 2700,
      status: "shipped",
      date: "2026-02-08",
    },
    {
      id: "ORD-2024-002",
      type: "vehicle",
      items: [{ name: "Mahindra Tractor 575", quantity: 1, price: 3500 }],
      total: 3500,
      status: "delivered",
      date: "2026-02-05",
      vehicleName: "Mahindra Tractor 575",
      bookingDate: "2026-02-06",
      timeSlot: "Morning (6:00 AM - 12:00 PM)",
    },
    {
      id: "ORD-2024-003",
      type: "product",
      items: [
        { name: "Organic Vermicompost", quantity: 5, price: 280 },
        { name: "Neem Oil Pesticide", quantity: 2, price: 320 },
      ],
      total: 2040,
      status: "processing",
      date: "2026-02-10",
    },
  ])

  const addOrder = useCallback((order: Order) => {
    setOrders((prev) => [order, ...prev.filter((item) => item.id !== order.id)])
  }, [])

  useEffect(() => {
    let cancelled = false
    fetch("/api/orders", { cache: "no-store" })
      .then((response) => (response.ok ? response.json() : { orders: [] }))
      .then((data) => {
        if (cancelled || !Array.isArray(data.orders) || data.orders.length === 0) return
        const normalized = data.orders.map((order: Order) => ({
          ...order,
          id: order.id,
          payment: order.payment
            ? { ...order.payment, paidAt: order.payment.paidAt ? new Date(order.payment.paidAt) : undefined }
            : undefined,
        }))
        setOrders((prev) => {
          const byId = new Map(prev.map((order) => [order.id, order]))
          for (const order of normalized) byId.set(order.id, order)
          return Array.from(byId.values()).sort((a, b) => b.date.localeCompare(a.date))
        })
      })
      .catch(() => {})
    return () => { cancelled = true }
  }, [])

  return (
    <OrderContext.Provider value={{ orders, addOrder }}>
      {children}
    </OrderContext.Provider>
  )
}

export function useOrders() {
  const context = useContext(OrderContext)
  if (!context) throw new Error("useOrders must be used within OrderProvider")
  return context
}
