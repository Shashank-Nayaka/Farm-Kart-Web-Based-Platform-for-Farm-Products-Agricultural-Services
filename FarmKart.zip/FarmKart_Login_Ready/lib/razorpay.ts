export type RazorpayPaymentResult = {
  razorpay_payment_id: string
  razorpay_order_id: string
  razorpay_signature: string
}

type RazorpayOptions = {
  key: string
  amount: number
  currency: string
  name: string
  description: string
  order_id: string
  prefill?: { name?: string; email?: string; contact?: string }
  theme?: { color?: string }
  handler: (result: RazorpayPaymentResult) => void | Promise<void>
  modal?: { ondismiss?: () => void }
}

type RazorpayInstance = { open: () => void }
type RazorpayConstructor = new (options: RazorpayOptions) => RazorpayInstance

declare global {
  interface Window {
    Razorpay?: RazorpayConstructor
  }
}

export async function loadRazorpay(): Promise<boolean> {
  if (typeof window === "undefined") return false
  if (window.Razorpay) return true

  return new Promise((resolve) => {
    const existing = document.querySelector<HTMLScriptElement>('script[src="https://checkout.razorpay.com/v1/checkout.js"]')
    if (existing) {
      existing.addEventListener("load", () => resolve(Boolean(window.Razorpay)), { once: true })
      existing.addEventListener("error", () => resolve(false), { once: true })
      return
    }

    const script = document.createElement("script")
    script.src = "https://checkout.razorpay.com/v1/checkout.js"
    script.async = true
    script.onload = () => resolve(Boolean(window.Razorpay))
    script.onerror = () => resolve(false)
    document.body.appendChild(script)
  })
}

export async function startRazorpayCheckout(options: RazorpayOptions) {
  const loaded = await loadRazorpay()
  if (!loaded || !window.Razorpay) throw new Error("Razorpay checkout could not be loaded. Check your internet connection.")
  const razorpay = new window.Razorpay(options)
  razorpay.open()
}
