import { cookies } from "next/headers"
import { ObjectId } from "mongodb"
import crypto from "node:crypto"
import { getDb } from "./mongodb"

const SESSION_COOKIE = "farmkart_session"
const SESSION_DAYS = 7

export type AuthUser = {
  id: string
  name: string
  email: string
  phone?: string
}

function hashToken(token: string) {
  return crypto.createHash("sha256").update(token).digest("hex")
}

export async function createSession(userId: string) {
  const db = await getDb()
  const rawToken = crypto.randomBytes(32).toString("hex")
  const tokenHash = hashToken(rawToken)
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000)

  await db.collection("sessions").insertOne({
    userId: new ObjectId(userId),
    tokenHash,
    expiresAt,
    createdAt: new Date(),
  })

  const cookieStore = await cookies()
  cookieStore.set(SESSION_COOKIE, rawToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_DAYS * 24 * 60 * 60,
  })
}

export async function getCurrentUser(): Promise<AuthUser | null> {
  const cookieStore = await cookies()
  const rawToken = cookieStore.get(SESSION_COOKIE)?.value

  if (!rawToken) return null

  const db = await getDb()
  const session = await db.collection("sessions").findOne({
    tokenHash: hashToken(rawToken),
    expiresAt: { $gt: new Date() },
  })

  if (!session) return null

  const user = await db.collection("users").findOne({
    _id: new ObjectId(session.userId),
  })

  if (!user) return null

  return {
    id: user._id.toString(),
    name: user.name,
    email: user.email,
    phone: user.phone,
  }
}

export async function deleteCurrentSession() {
  const cookieStore = await cookies()
  const rawToken = cookieStore.get(SESSION_COOKIE)?.value

  if (rawToken) {
    const db = await getDb()
    await db.collection("sessions").deleteOne({
      tokenHash: hashToken(rawToken),
    })
  }

  cookieStore.set(SESSION_COOKIE, "", {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 0,
  })
}
