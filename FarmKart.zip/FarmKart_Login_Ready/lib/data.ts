export type Category =
  | "seeds"
  | "fertilizers"
  | "tools"
  | "animal-feed"

export interface Product {
  id: string
  name: string
  description: string
  price: number
  unit: string
  category: Category
  rating: number
  reviews: number
  icon: string
  inStock: boolean
  featured?: boolean
}

export interface Vehicle {
  id: string
  name: string
  description: string
  icon: string
  hourlyRate: number
  dailyRate: number
  available: boolean
  specs: string[]
}

export interface CartItem {
  product: Product
  quantity: number
}

export interface Order {
  id: string
  type: "product" | "vehicle"
  items: { name: string; quantity: number; price: number }[]
  total: number
  status: "ordered" | "processing" | "shipped" | "delivered"
  date: string
  vehicleName?: string
  bookingDate?: string
  timeSlot?: string
  durationType?: "hourly" | "daily"
  hours?: number
  location?: string
  payment?: {
    status: "paid" | "failed" | "pending"
    method: string
    razorpayPaymentId?: string
    razorpayOrderId?: string
    paidAt?: string | Date
  }
}

export const categories: { id: Category; name: string; icon: string; color: string; description: string }[] = [
  { id: "seeds", name: "Seeds & Plants", icon: "Sprout", color: "hsl(142, 76%, 36%)", description: "Premium quality crop seeds and saplings" },
  { id: "fertilizers", name: "Fertilizers & Pesticides", icon: "FlaskConical", color: "hsl(38, 92%, 50%)", description: "Organic and chemical solutions" },
  { id: "tools", name: "Tools & Equipment", icon: "Wrench", color: "hsl(199, 89%, 48%)", description: "Essential farming tools and irrigation" },
  { id: "animal-feed", name: "Animal Feed & Care", icon: "Heart", color: "hsl(0, 72%, 51%)", description: "Livestock feed and veterinary supplies" },
]

export const products: Product[] = [
  // Seeds & Plants
  { id: "p1", name: "Hybrid Wheat Seeds", description: "High-yield variety, suitable for Rabi season. Resistant to rust diseases.", price: 450, unit: "per 5kg bag", category: "seeds", rating: 4.5, reviews: 128, icon: "Wheat", inStock: true, featured: true },
  { id: "p2", name: "Basmati Rice Seeds", description: "Premium long-grain basmati. Excellent aroma and taste.", price: 680, unit: "per 5kg bag", category: "seeds", rating: 4.8, reviews: 215, icon: "Wheat", inStock: true, featured: true },
  { id: "p3", name: "Tomato Seedlings", description: "Hybrid cherry tomato seedlings. Ready to transplant.", price: 120, unit: "per tray (50 pcs)", category: "seeds", rating: 4.3, reviews: 89, icon: "Sprout", inStock: true },
  { id: "p4", name: "Mustard Seeds", description: "Yellow mustard seeds for oil production. Early maturity.", price: 350, unit: "per 5kg bag", category: "seeds", rating: 4.2, reviews: 67, icon: "Sprout", inStock: true },
  // Fertilizers & Pesticides
  { id: "p5", name: "Organic Vermicompost", description: "100% natural vermicompost. Rich in nutrients and beneficial microbes.", price: 280, unit: "per 25kg bag", category: "fertilizers", rating: 4.7, reviews: 342, icon: "FlaskConical", inStock: true, featured: true },
  { id: "p6", name: "DAP Fertilizer", description: "Di-ammonium phosphate for strong root development.", price: 1350, unit: "per 50kg bag", category: "fertilizers", rating: 4.4, reviews: 198, icon: "FlaskConical", inStock: true },
  { id: "p7", name: "Neem Oil Pesticide", description: "Natural neem-based pest control. Safe for organic farming.", price: 320, unit: "per litre", category: "fertilizers", rating: 4.6, reviews: 156, icon: "Droplets", inStock: true },
  { id: "p8", name: "Urea Fertilizer", description: "High nitrogen content for leafy growth. Water-soluble.", price: 550, unit: "per 50kg bag", category: "fertilizers", rating: 4.1, reviews: 289, icon: "FlaskConical", inStock: true },
  // Tools & Equipment
  { id: "p9", name: "Drip Irrigation Kit", description: "Complete kit for 1 acre. Saves 60% water.", price: 4500, unit: "per kit", category: "tools", rating: 4.8, reviews: 87, icon: "Droplets", inStock: true, featured: true },
  { id: "p10", name: "Manual Seed Drill", description: "Precision seed planting tool. Adjustable row spacing.", price: 2800, unit: "per piece", category: "tools", rating: 4.3, reviews: 54, icon: "Wrench", inStock: true },
  { id: "p11", name: "Knapsack Sprayer 16L", description: "Battery-operated backpack sprayer. Adjustable nozzle.", price: 1800, unit: "per piece", category: "tools", rating: 4.5, reviews: 143, icon: "Wrench", inStock: true },
  { id: "p12", name: "Garden Hoe Set", description: "3-piece forged steel hoe set. Wooden handles.", price: 650, unit: "per set", category: "tools", rating: 4.0, reviews: 76, icon: "Shovel", inStock: true },
  // Animal Feed & Care
  { id: "p13", name: "Cattle Feed Premium", description: "Balanced nutrition for dairy cattle. Increases milk yield.", price: 950, unit: "per 50kg bag", category: "animal-feed", rating: 4.6, reviews: 231, icon: "Heart", inStock: true },
  { id: "p14", name: "Poultry Starter Feed", description: "Complete starter feed for chicks. High protein formula.", price: 780, unit: "per 25kg bag", category: "animal-feed", rating: 4.4, reviews: 112, icon: "Heart", inStock: true },
  { id: "p15", name: "Mineral Lick Block", description: "Essential minerals and salt block for livestock.", price: 180, unit: "per block", category: "animal-feed", rating: 4.7, reviews: 189, icon: "Heart", inStock: true },
  { id: "p16", name: "Veterinary First Aid Kit", description: "Complete first aid kit for farm animals. Includes antiseptics.", price: 1200, unit: "per kit", category: "animal-feed", rating: 4.5, reviews: 98, icon: "Heart", inStock: true },
]

export const vehicles: Vehicle[] = [
  { id: "v1", name: "Mahindra Tractor 575", description: "45 HP tractor suitable for ploughing, tilling, and hauling. Perfect for medium farms.", icon: "Tractor", hourlyRate: 500, dailyRate: 3500, available: true, specs: ["45 HP", "2WD", "Diesel", "6+2 Gears"] },
  { id: "v2", name: "Combine Harvester", description: "Full-size combine for wheat and rice harvesting. Covers 4-5 acres per day.", icon: "Tractor", hourlyRate: 1200, dailyRate: 8000, available: true, specs: ["Track Type", "14 ft Cut", "Grain Tank 2500L", "GPS Enabled"] },
  { id: "v3", name: "Sugarcane Crusher", description: "Heavy-duty juice extraction crusher. Portable, diesel-powered.", icon: "Cog", hourlyRate: 350, dailyRate: 2500, available: true, specs: ["3 Roller", "Diesel", "Portable", "500L/hr"] },
  { id: "v4", name: "Rotavator", description: "Soil preparation rotavator attachment. Creates fine seedbed in one pass.", icon: "Cog", hourlyRate: 400, dailyRate: 2800, available: false, specs: ["6 ft Width", "42 Blades", "3-Point Hitch", "Multi-Speed"] },
  { id: "v5", name: "Tractor Trolley", description: "Heavy-duty hydraulic tipping trolley for transport of harvest and materials.", icon: "Truck", hourlyRate: 300, dailyRate: 2000, available: true, specs: ["4 Tonne", "Hydraulic Tip", "Steel Body", "Leaf Spring"] },
  { id: "v6", name: "Sprayer Drone", description: "Agricultural drone for precision pesticide and fertilizer spraying.", icon: "Plane", hourlyRate: 800, dailyRate: 5500, available: true, specs: ["10L Tank", "GPS Guided", "15 min Flight", "5 Acre/hr"] },
]

export const timeSlots = [
  { id: "morning", label: "Morning", time: "6:00 AM - 12:00 PM" },
  { id: "afternoon", label: "Afternoon", time: "12:00 PM - 5:00 PM" },
  { id: "evening", label: "Evening", time: "5:00 PM - 8:00 PM" },
]
