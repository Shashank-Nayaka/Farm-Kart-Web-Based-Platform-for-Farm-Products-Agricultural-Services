"use client"

import Link from "next/link"
import { FormEvent, useEffect, useState } from "react"
import { Leaf, Loader2, LockKeyhole, Mail, Phone, UserRound } from "lucide-react"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { useAuth } from "@/lib/auth-context"

export default function LoginPage() {
  const router = useRouter()
  const { user, loading: authLoading, refreshUser } = useAuth()

  const [mode, setMode] = useState<"login" | "signup">("login")
  const [busy, setBusy] = useState(false)

  const [loginForm, setLoginForm] = useState({ email: "", password: "" })
  const [signupForm, setSignupForm] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
  })

  useEffect(() => {
    if (!authLoading && user) {
      router.replace("/")
    }
  }, [authLoading, user, router])

  function switchMode(nextMode: "login" | "signup") {
    setMode(nextMode)
    router.replace("/login")
  }

  async function handleLogin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setBusy(true)

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(loginForm),
      })
      const data = await response.json()

      if (!response.ok) {
        toast.error(data.error || "Login failed.")
        return
      }

      await refreshUser()
      toast.success(`Welcome back, ${data.user.name}!`)
      router.replace("/")
    } catch {
      toast.error("Could not connect to the server.")
    } finally {
      setBusy(false)
    }
  }

  async function handleSignup(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()

    if (signupForm.password !== signupForm.confirmPassword) {
      toast.error("Passwords do not match.")
      return
    }

    setBusy(true)

    try {
      const response = await fetch("/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: signupForm.name,
          email: signupForm.email,
          phone: signupForm.phone,
          password: signupForm.password,
        }),
      })
      const data = await response.json()

      if (!response.ok) {
        toast.error(data.error || "Account creation failed.")
        return
      }

      await refreshUser()
      toast.success("Account created successfully!")
      router.replace("/")
    } catch {
      toast.error("Could not connect to the server.")
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-muted/30 px-4 py-12">
      <div className="mx-auto grid max-w-5xl overflow-hidden rounded-2xl border bg-background shadow-xl lg:grid-cols-2">
        <div className="hidden bg-primary p-10 text-primary-foreground lg:flex lg:flex-col lg:justify-between">
          <div>
            <div className="flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary-foreground/15">
                <Leaf className="h-6 w-6" />
              </div>
              <span className="text-2xl font-bold">
                Farm<span className="text-primary-foreground/70">Kart</span>
              </span>
            </div>
            <h2 className="mt-14 text-4xl font-extrabold leading-tight">
              Everything your farm needs, in one place.
            </h2>
            <p className="mt-5 max-w-md text-primary-foreground/80">
              Shop agricultural products, book farming vehicles, and manage
              your FarmKart orders from one secure account.
            </p>
          </div>
          <p className="text-sm text-primary-foreground/70">
            Secure account access for FarmKart customers.
          </p>
        </div>

        <Card className="rounded-none border-0 shadow-none">
          <CardHeader className="space-y-2 p-6 pb-3 sm:p-8 sm:pb-4">
            <div className="mb-2 flex items-center gap-2 lg:hidden">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
                <Leaf className="h-5 w-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold">
                Farm<span className="text-primary">Kart</span>
              </span>
            </div>
            <CardTitle className="text-2xl">
              {mode === "login" ? "Welcome back" : "Create your account"}
            </CardTitle>
            <CardDescription>
              {mode === "login"
                ? "Login to continue to FarmKart."
                : "Register once, then use your FarmKart account everywhere."}
            </CardDescription>
          </CardHeader>

          <CardContent className="p-6 pt-2 sm:p-8 sm:pt-3">
            <div className="mb-6 grid grid-cols-2 rounded-lg bg-muted p-1">
              <button
                type="button"
                onClick={() => switchMode("login")}
                className={`rounded-md px-3 py-2 text-sm font-semibold transition ${
                  mode === "login" ? "bg-background shadow-sm" : "text-muted-foreground"
                }`}
              >
                Login
              </button>
              <button
                type="button"
                onClick={() => switchMode("signup")}
                className={`rounded-md px-3 py-2 text-sm font-semibold transition ${
                  mode === "signup" ? "bg-background shadow-sm" : "text-muted-foreground"
                }`}
              >
                Create account
              </button>
            </div>

            {mode === "login" ? (
              <form className="flex flex-col gap-5" onSubmit={handleLogin}>
                <div className="flex flex-col gap-1.5">
                  <Label htmlFor="login-email">Email address</Label>
                  <div className="relative">
                    <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="login-email"
                      type="email"
                      required
                      autoComplete="email"
                      placeholder="you@example.com"
                      className="pl-9"
                      value={loginForm.email}
                      onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
                    />
                  </div>
                </div>

                <div className="flex flex-col gap-1.5">
                  <Label htmlFor="login-password">Password</Label>
                  <div className="relative">
                    <LockKeyhole className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="login-password"
                      type="password"
                      required
                      autoComplete="current-password"
                      placeholder="Enter your password"
                      className="pl-9"
                      value={loginForm.password}
                      onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                    />
                  </div>
                </div>

                <Button type="submit" size="lg" disabled={busy} className="w-full">
                  {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  Login
                </Button>
              </form>
            ) : (
              <form className="flex flex-col gap-4" onSubmit={handleSignup}>
                <div className="flex flex-col gap-1.5">
                  <Label htmlFor="signup-name">Full name</Label>
                  <div className="relative">
                    <UserRound className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="signup-name"
                      required
                      autoComplete="name"
                      placeholder="Your full name"
                      className="pl-9"
                      value={signupForm.name}
                      onChange={(e) => setSignupForm({ ...signupForm, name: e.target.value })}
                    />
                  </div>
                </div>

                <div className="flex flex-col gap-1.5">
                  <Label htmlFor="signup-email">Email address</Label>
                  <div className="relative">
                    <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="signup-email"
                      type="email"
                      required
                      autoComplete="email"
                      placeholder="you@example.com"
                      className="pl-9"
                      value={signupForm.email}
                      onChange={(e) => setSignupForm({ ...signupForm, email: e.target.value })}
                    />
                  </div>
                </div>

                <div className="flex flex-col gap-1.5">
                  <Label htmlFor="signup-phone">Phone number (optional)</Label>
                  <div className="relative">
                    <Phone className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="signup-phone"
                      type="tel"
                      autoComplete="tel"
                      placeholder="9876543210"
                      className="pl-9"
                      value={signupForm.phone}
                      onChange={(e) => setSignupForm({ ...signupForm, phone: e.target.value })}
                    />
                  </div>
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="flex flex-col gap-1.5">
                    <Label htmlFor="signup-password">Password</Label>
                    <Input
                      id="signup-password"
                      type="password"
                      required
                      minLength={8}
                      autoComplete="new-password"
                      placeholder="Minimum 8 characters"
                      value={signupForm.password}
                      onChange={(e) => setSignupForm({ ...signupForm, password: e.target.value })}
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <Label htmlFor="signup-confirm">Confirm password</Label>
                    <Input
                      id="signup-confirm"
                      type="password"
                      required
                      minLength={8}
                      autoComplete="new-password"
                      placeholder="Repeat password"
                      value={signupForm.confirmPassword}
                      onChange={(e) =>
                        setSignupForm({ ...signupForm, confirmPassword: e.target.value })
                      }
                    />
                  </div>
                </div>

                <Button type="submit" size="lg" disabled={busy} className="mt-1 w-full">
                  {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  Create account
                </Button>
              </form>
            )}

            <div className="my-6 flex items-center gap-3">
              <Separator />
              <span className="shrink-0 text-xs text-muted-foreground">FarmKart account</span>
              <Separator />
            </div>

            <p className="text-center text-xs text-muted-foreground">
              By continuing, you agree to use FarmKart responsibly and keep your
              login details secure.
            </p>

            <p className="mt-5 text-center text-sm text-muted-foreground">
              <Link href="/" className="font-medium text-primary hover:underline">
                Back to FarmKart
              </Link>
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
