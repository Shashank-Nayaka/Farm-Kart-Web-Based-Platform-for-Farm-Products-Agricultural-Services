"use client"

import { useState } from "react"
import { AuthGuard } from "@/components/auth-guard"
import {
  Package,
  Truck,
  CheckCircle2,
  Clock,
  CalendarDays,
  IndianRupee,
  ShoppingBag,
  ClipboardList,
  CreditCard,
  MapPin,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { useOrders } from "@/lib/store"

const statusSteps = ["ordered", "processing", "shipped", "delivered"] as const
const statusConfig: Record<
  string,
  { label: string; color: string; icon: React.ElementType }
> = {
  ordered: { label: "Ordered", color: "bg-accent text-accent-foreground", icon: Clock },
  processing: { label: "Processing", color: "bg-secondary text-secondary-foreground", icon: Package },
  shipped: { label: "Shipped", color: "bg-primary text-primary-foreground", icon: Truck },
  delivered: { label: "Delivered", color: "bg-primary text-primary-foreground", icon: CheckCircle2 },
}

function OrderTimeline({ status }: { status: string }) {
  const currentIndex = statusSteps.indexOf(
    status as (typeof statusSteps)[number]
  )

  return (
    <div className="flex items-center gap-1">
      {statusSteps.map((step, i) => {
        const isCompleted = i <= currentIndex
        const StepIcon = statusConfig[step].icon
        return (
          <div key={step} className="flex items-center">
            <div
              className={`flex h-8 w-8 items-center justify-center rounded-full border-2 transition-colors ${
                isCompleted
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-muted-foreground/30 bg-background text-muted-foreground/40"
              }`}
            >
              <StepIcon className="h-3.5 w-3.5" />
            </div>
            {i < statusSteps.length - 1 && (
              <div
                className={`mx-1 h-0.5 w-6 rounded sm:w-10 ${
                  i < currentIndex ? "bg-primary" : "bg-muted-foreground/20"
                }`}
              />
            )}
          </div>
        )
      })}
    </div>
  )
}

function OrderStepLabels({ status }: { status: string }) {
  const currentIndex = statusSteps.indexOf(
    status as (typeof statusSteps)[number]
  )
  return (
    <div className="flex gap-1">
      {statusSteps.map((step, i) => {
        const isCompleted = i <= currentIndex
        return (
          <div key={step} className="flex items-center">
            <span
              className={`text-[10px] ${
                isCompleted
                  ? "font-medium text-foreground"
                  : "text-muted-foreground/50"
              }`}
            >
              {statusConfig[step].label}
            </span>
            {i < statusSteps.length - 1 && <div className="mx-1 w-6 sm:w-10" />}
          </div>
        )
      })}
    </div>
  )
}

function OrdersPageContent() {
  const { orders } = useOrders()
  const [tab, setTab] = useState("products")

  const productOrders = orders.filter((o) => o.type === "product")
  const vehicleBookings = orders.filter((o) => o.type === "vehicle")

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 lg:px-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground">My Orders</h1>
        <p className="mt-1 text-muted-foreground">
          Track your product orders and vehicle bookings
        </p>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="mb-6">
          <TabsTrigger value="products" className="gap-1.5">
            <ShoppingBag className="h-4 w-4" />
            Product Orders ({productOrders.length})
          </TabsTrigger>
          <TabsTrigger value="vehicles" className="gap-1.5">
            <Truck className="h-4 w-4" />
            Vehicle Bookings ({vehicleBookings.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="products">
          {productOrders.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center">
              <ShoppingBag className="mb-4 h-16 w-16 text-muted-foreground/30" />
              <h3 className="text-lg font-semibold text-foreground">
                No product orders yet
              </h3>
              <p className="text-sm text-muted-foreground">
                Your product orders will appear here
              </p>
            </div>
          ) : (
            <div className="flex flex-col gap-4">
              {productOrders.map((order) => (
                <Card key={order.id}>
                  <CardHeader className="pb-3">
                    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                          <Package className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <CardTitle className="text-sm font-semibold">
                            {order.id}
                          </CardTitle>
                          <p className="flex items-center gap-1 text-xs text-muted-foreground">
                            <CalendarDays className="h-3 w-3" />
                            {order.date}
                          </p>
                        </div>
                      </div>
                      <Badge
                        className={`w-fit capitalize ${statusConfig[order.status]?.color || ""}`}
                      >
                        {statusConfig[order.status]?.label || order.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="flex flex-col gap-4">
                    {/* Items */}
                    <div className="flex flex-col gap-2">
                      {order.items.map((item, i) => (
                        <div
                          key={i}
                          className="flex items-center justify-between text-sm"
                        >
                          <span className="text-muted-foreground">
                            {item.name} x {item.quantity}
                          </span>
                          <span className="font-medium text-foreground">
                            Rs {item.price * item.quantity}
                          </span>
                        </div>
                      ))}
                    </div>
                    <Separator />
                    {order.payment && (
                      <div className="rounded-lg border bg-primary/5 p-3 text-sm">
                        <div className="mb-1 flex items-center gap-2 font-semibold text-foreground">
                          <CreditCard className="h-4 w-4 text-primary" />
                          Payment Details
                        </div>
                        <div className="grid gap-1 text-muted-foreground sm:grid-cols-2">
                          <span>Status: <span className="font-medium text-primary capitalize">{order.payment.status}</span></span>
                          <span>Method: <span className="font-medium text-foreground">{order.payment.method}</span></span>
                          <span className="truncate">Payment ID: <span className="font-medium text-foreground">{order.payment.razorpayPaymentId}</span></span>
                          <span>Payment Order ID: <span className="font-medium text-foreground">{order.payment.razorpayOrderId}</span></span>
                        </div>
                      </div>
                    )}
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-foreground">
                        Total
                      </span>
                      <span className="flex items-center gap-1 text-lg font-bold text-primary">
                        <IndianRupee className="h-4 w-4" />
                        {order.total}
                      </span>
                    </div>
                    {/* Timeline */}
                    <div className="flex flex-col gap-1.5 pt-2">
                      <OrderTimeline status={order.status} />
                      <OrderStepLabels status={order.status} />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="vehicles">
          {vehicleBookings.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center">
              <Truck className="mb-4 h-16 w-16 text-muted-foreground/30" />
              <h3 className="text-lg font-semibold text-foreground">
                No vehicle bookings yet
              </h3>
              <p className="text-sm text-muted-foreground">
                Your vehicle bookings will appear here
              </p>
            </div>
          ) : (
            <div className="flex flex-col gap-4">
              {vehicleBookings.map((booking) => (
                <Card key={booking.id}>
                  <CardHeader className="pb-3">
                    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary/10">
                          <Truck className="h-5 w-5 text-secondary" />
                        </div>
                        <div>
                          <CardTitle className="text-sm font-semibold">
                            {booking.vehicleName}
                          </CardTitle>
                          <p className="text-xs text-muted-foreground">
                            {booking.id}
                          </p>
                        </div>
                      </div>
                      <Badge
                        className={`w-fit capitalize ${statusConfig[booking.status]?.color || ""}`}
                      >
                        {statusConfig[booking.status]?.label || booking.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="flex flex-col gap-3">
                    <div className="grid gap-2 sm:grid-cols-2">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <CalendarDays className="h-3.5 w-3.5" />
                        <span>
                          Booking Date:{" "}
                          <span className="font-medium text-foreground">
                            {booking.bookingDate}
                          </span>
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Clock className="h-3.5 w-3.5" />
                        <span>
                          Time:{" "}
                          <span className="font-medium text-foreground">
                            {booking.timeSlot}
                          </span>
                        </span>
                      </div>
                    </div>
                    <Separator />
                    {booking.location && (
                      <div className="flex items-start gap-2 text-sm text-muted-foreground">
                        <MapPin className="mt-0.5 h-3.5 w-3.5" />
                        <span>Farm Location: <span className="font-medium text-foreground">{booking.location}</span></span>
                      </div>
                    )}
                    {booking.payment && (
                      <div className="rounded-lg border bg-primary/5 p-3 text-sm">
                        <div className="mb-1 flex items-center gap-2 font-semibold text-foreground">
                          <CreditCard className="h-4 w-4 text-primary" />
                          Payment Details
                        </div>
                        <div className="grid gap-1 text-muted-foreground sm:grid-cols-2">
                          <span>Status: <span className="font-medium text-primary capitalize">{booking.payment.status}</span></span>
                          <span>Method: <span className="font-medium text-foreground">{booking.payment.method}</span></span>
                          <span className="truncate">Payment ID: <span className="font-medium text-foreground">{booking.payment.razorpayPaymentId}</span></span>
                          <span>Payment Order ID: <span className="font-medium text-foreground">{booking.payment.razorpayOrderId}</span></span>
                        </div>
                      </div>
                    )}
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-foreground">
                        Total
                      </span>
                      <span className="flex items-center gap-1 text-lg font-bold text-primary">
                        <IndianRupee className="h-4 w-4" />
                        {booking.total}
                      </span>
                    </div>
                    {/* Timeline */}
                    <div className="flex flex-col gap-1.5 pt-2">
                      <OrderTimeline status={booking.status} />
                      <OrderStepLabels status={booking.status} />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}


export default function OrdersPage() {
  return (
    <AuthGuard>
      <OrdersPageContent />
    </AuthGuard>
  )
}
