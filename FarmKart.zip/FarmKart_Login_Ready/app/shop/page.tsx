"use client"

import { useState, useMemo } from "react"
import { useSearchParams } from "next/navigation"
import {
  Search,
  Star,
  Plus,
  Minus,
  ShoppingCart,
  Trash2,
  ArrowUpDown,
  X,
  ShoppingBag,
  Sprout,
  FlaskConical,
  Wrench,
  Heart,
  Package,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetFooter,
} from "@/components/ui/sheet"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { ScrollArea } from "@/components/ui/scroll-area"
import { products, type Category } from "@/lib/data"
import { useCart } from "@/lib/store"
import { useOrders } from "@/lib/store"
import { useAuth } from "@/lib/auth-context"
import { startRazorpayCheckout } from "@/lib/razorpay"
import { toast } from "sonner"

const categoryFilters: {
  id: Category | "all"
  label: string
  icon: React.ElementType
}[] = [
  { id: "all", label: "All Products", icon: Package },
  { id: "seeds", label: "Seeds & Plants", icon: Sprout },
  { id: "fertilizers", label: "Fertilizers", icon: FlaskConical },
  { id: "tools", label: "Tools & Equipment", icon: Wrench },
  { id: "animal-feed", label: "Animal Feed", icon: Heart },
]

const categoryEmoji: Record<string, string> = {
  seeds: "\u{1F33E}",
  fertilizers: "\u{1F9EA}",
  tools: "\u{1F4A7}",
  "animal-feed": "\u{1F404}",
}

type SortOption = "name" | "price-asc" | "price-desc" | "rating"

export default function ShopPage() {
  const searchParams = useSearchParams()
  const initialCategory = (searchParams.get("category") as Category) || "all"

  const [category, setCategory] = useState<Category | "all">(initialCategory)
  const [search, setSearch] = useState("")
  const [sort, setSort] = useState<SortOption>("rating")
  const [cartOpen, setCartOpen] = useState(false)

  const { items, addToCart, removeFromCart, updateQuantity, clearCart, totalItems, totalPrice } = useCart()
  const { addOrder } = useOrders()
  const { user } = useAuth()
  const [paying, setPaying] = useState(false)

  const filtered = useMemo(() => {
    let list = [...products]
    if (category !== "all") list = list.filter((p) => p.category === category)
    if (search.trim()) {
      const q = search.toLowerCase()
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q)
      )
    }
    switch (sort) {
      case "name":
        list.sort((a, b) => a.name.localeCompare(b.name))
        break
      case "price-asc":
        list.sort((a, b) => a.price - b.price)
        break
      case "price-desc":
        list.sort((a, b) => b.price - a.price)
        break
      case "rating":
        list.sort((a, b) => b.rating - a.rating)
        break
    }
    return list
  }, [category, search, sort])

  const getCartQuantity = (productId: string) => {
    const item = items.find((i) => i.product.id === productId)
    return item?.quantity || 0
  }

  const handleCheckout = async () => {
    if (items.length === 0) return
    if (!user) {
      toast.error("Please log in before placing an order.")
      window.location.href = "/login"
      return
    }

    setPaying(true)
    try {
      const createResponse = await fetch("/api/payment/create-order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "product",
          items: items.map((item) => ({
            productId: item.product.id,
            quantity: item.quantity,
          })),
        }),
      })
      const createData = await createResponse.json()
      if (!createResponse.ok) throw new Error(createData.error || "Unable to start payment.")

      await startRazorpayCheckout({
        key: createData.keyId,
        amount: createData.amount,
        currency: createData.currency,
        name: "FarmKart",
        description: "FarmKart agricultural product order",
        order_id: createData.razorpayOrderId,
        prefill: { name: createData.name, email: createData.email, contact: createData.phone },
        theme: { color: "#16a34a" },
        handler: async (result) => {
          try {
            const verifyResponse = await fetch("/api/payment/verify", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(result),
            })
            const verifyData = await verifyResponse.json()
            if (!verifyResponse.ok) throw new Error(verifyData.error || "Payment verification failed.")

            const saved = verifyData.order
            addOrder({ ...saved, id: saved.id || saved.appOrderId })
            clearCart()
            setCartOpen(false)
            toast.success("Payment successful!", { description: `Order ${saved.id} is confirmed.` })
          } catch (error) {
            toast.error(error instanceof Error ? error.message : "Payment verification failed.")
          } finally {
            setPaying(false)
          }
        },
        modal: { ondismiss: () => setPaying(false) },
      })
    } catch (error) {
      setPaying(false)
      toast.error(error instanceof Error ? error.message : "Unable to start payment.")
    }
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 lg:px-8">
      {/* Header */}
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Shop</h1>
          <p className="mt-1 text-muted-foreground">
            {filtered.length} products available
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Sheet open={cartOpen} onOpenChange={setCartOpen}>
            <SheetTrigger asChild>
              <Button className="relative">
                <ShoppingCart className="mr-2 h-4 w-4" />
                Cart
                {totalItems > 0 && (
                  <Badge className="ml-2 bg-secondary text-secondary-foreground">
                    {totalItems}
                  </Badge>
                )}
              </Button>
            </SheetTrigger>
            <SheetContent className="flex w-full flex-col sm:max-w-md">
              <SheetHeader>
                <SheetTitle className="flex items-center gap-2">
                  <ShoppingBag className="h-5 w-5 text-primary" />
                  Your Cart ({totalItems} items)
                </SheetTitle>
              </SheetHeader>
              {items.length === 0 ? (
                <div className="flex flex-1 flex-col items-center justify-center gap-3 text-center">
                  <ShoppingCart className="h-16 w-16 text-muted-foreground/30" />
                  <p className="text-lg font-medium text-muted-foreground">
                    Your cart is empty
                  </p>
                  <Button
                    variant="outline"
                    onClick={() => setCartOpen(false)}
                  >
                    Browse Products
                  </Button>
                </div>
              ) : (
                <>
                  <ScrollArea className="flex-1 pr-4">
                    <div className="flex flex-col gap-4 py-4">
                      {items.map((item) => (
                        <div
                          key={item.product.id}
                          className="flex items-start gap-3 rounded-lg border p-3"
                        >
                          <div className="flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-md bg-muted text-2xl">
                            {categoryEmoji[item.product.category] || "\u{1F33F}"}
                          </div>
                          <div className="flex-1">
                            <h4 className="text-sm font-medium text-foreground">
                              {item.product.name}
                            </h4>
                            <p className="text-xs text-muted-foreground">
                              Rs {item.product.price} {item.product.unit}
                            </p>
                            <div className="mt-2 flex items-center gap-2">
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-7 w-7"
                                onClick={() =>
                                  updateQuantity(
                                    item.product.id,
                                    item.quantity - 1
                                  )
                                }
                              >
                                <Minus className="h-3 w-3" />
                              </Button>
                              <span className="w-6 text-center text-sm font-medium">
                                {item.quantity}
                              </span>
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-7 w-7"
                                onClick={() =>
                                  updateQuantity(
                                    item.product.id,
                                    item.quantity + 1
                                  )
                                }
                              >
                                <Plus className="h-3 w-3" />
                              </Button>
                            </div>
                          </div>
                          <div className="flex flex-col items-end gap-1">
                            <span className="text-sm font-semibold text-foreground">
                              Rs {item.product.price * item.quantity}
                            </span>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-7 w-7 text-destructive hover:text-destructive"
                              onClick={() =>
                                removeFromCart(item.product.id)
                              }
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                  <Separator />
                  <SheetFooter className="flex-col gap-3 pt-4 sm:flex-col">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">
                        Subtotal
                      </span>
                      <span className="text-sm font-medium">
                        Rs {totalPrice}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">
                        Delivery
                      </span>
                      <span className="text-sm font-medium text-primary">
                        FREE
                      </span>
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-foreground">
                        Total
                      </span>
                      <span className="text-xl font-bold text-primary">
                        Rs {totalPrice}
                      </span>
                    </div>
                    <Button
                      className="w-full"
                      size="lg"
                      onClick={handleCheckout}
                      disabled={paying}
                    >
                      {paying ? "Opening payment..." : "Proceed to Payment"}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-destructive"
                      onClick={clearCart}
                    >
                      Clear Cart
                    </Button>
                  </SheetFooter>
                </>
              )}
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search products..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
          {search && (
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-1 top-1/2 h-7 w-7 -translate-y-1/2"
              onClick={() => setSearch("")}
            >
              <X className="h-3.5 w-3.5" />
            </Button>
          )}
        </div>
        <div className="flex items-center gap-2">
          <ArrowUpDown className="h-4 w-4 text-muted-foreground" />
          <Select
            value={sort}
            onValueChange={(v) => setSort(v as SortOption)}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="rating">Top Rated</SelectItem>
              <SelectItem value="price-asc">Price: Low to High</SelectItem>
              <SelectItem value="price-desc">Price: High to Low</SelectItem>
              <SelectItem value="name">Name A-Z</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="mb-8 flex flex-wrap gap-2">
        {categoryFilters.map((cat) => {
          const isActive = category === cat.id
          return (
            <Button
              key={cat.id}
              variant={isActive ? "default" : "outline"}
              size="sm"
              onClick={() => setCategory(cat.id)}
              className={isActive ? "" : "text-muted-foreground"}
            >
              <cat.icon className="mr-1.5 h-4 w-4" />
              {cat.label}
            </Button>
          )
        })}
      </div>

      {/* Product Grid */}
      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <Search className="mb-4 h-16 w-16 text-muted-foreground/30" />
          <h3 className="text-lg font-semibold text-foreground">
            No products found
          </h3>
          <p className="text-sm text-muted-foreground">
            Try changing your search or filters
          </p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filtered.map((product) => {
            const qty = getCartQuantity(product.id)
            return (
              <Card
                key={product.id}
                className="group overflow-hidden transition-all hover:-translate-y-0.5 hover:shadow-lg"
              >
                <CardContent className="p-4">
                  <div className="mb-3 flex h-28 items-center justify-center rounded-lg bg-muted/60">
                    <span
                      className="text-5xl"
                      role="img"
                      aria-label={product.name}
                    >
                      {categoryEmoji[product.category] || "\u{1F33F}"}
                    </span>
                  </div>
                  <Badge
                    variant="secondary"
                    className="mb-2 text-[10px] uppercase tracking-wider"
                  >
                    {product.category === "seeds"
                      ? "Seeds & Plants"
                      : product.category === "fertilizers"
                        ? "Fertilizers"
                        : product.category === "tools"
                          ? "Tools"
                          : "Animal Feed"}
                  </Badge>
                  <h3 className="text-sm font-semibold text-foreground leading-snug">
                    {product.name}
                  </h3>
                  <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-muted-foreground">
                    {product.description}
                  </p>
                  <div className="mt-2 flex items-center gap-1">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`h-3 w-3 ${
                          i < Math.floor(product.rating)
                            ? "fill-secondary text-secondary"
                            : "text-muted-foreground/30"
                        }`}
                      />
                    ))}
                    <span className="ml-1 text-xs text-muted-foreground">
                      ({product.reviews})
                    </span>
                  </div>
                  <div className="mt-3 flex items-center justify-between">
                    <div>
                      <span className="text-lg font-bold text-primary">
                        Rs {product.price}
                      </span>
                      <span className="ml-1 text-[10px] text-muted-foreground">
                        {product.unit}
                      </span>
                    </div>
                    {qty > 0 ? (
                      <div className="flex items-center gap-1.5">
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() =>
                            updateQuantity(product.id, qty - 1)
                          }
                        >
                          <Minus className="h-3 w-3" />
                        </Button>
                        <span className="w-5 text-center text-sm font-semibold">
                          {qty}
                        </span>
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() =>
                            updateQuantity(product.id, qty + 1)
                          }
                        >
                          <Plus className="h-3 w-3" />
                        </Button>
                      </div>
                    ) : (
                      <Button
                        size="sm"
                        onClick={() => {
                          addToCart(product)
                          toast.success(`${product.name} added to cart`)
                        }}
                      >
                        <Plus className="mr-1 h-3.5 w-3.5" />
                        Add
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}
