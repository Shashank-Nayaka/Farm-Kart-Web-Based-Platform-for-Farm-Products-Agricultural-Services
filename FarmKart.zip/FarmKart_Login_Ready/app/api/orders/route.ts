import { NextResponse } from "next/server"
import { ObjectId } from "mongodb"
import { getCurrentUser } from "@/lib/auth"
import { getDb } from "@/lib/mongodb"

export async function GET() {
  try {
    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ orders: [] })
    const db = await getDb()
    const orders = await db.collection("orders").find({ userId: new ObjectId(user.id) }).sort({ createdAt: -1 }).limit(100).toArray()
    return NextResponse.json({ orders: orders.map((o) => ({ ...o, id: o.appOrderId, _id: undefined, userId: undefined })) })
  } catch (error) {
    console.error("Get orders error:", error)
    return NextResponse.json({ error: "Unable to load orders." }, { status: 500 })
  }
}
