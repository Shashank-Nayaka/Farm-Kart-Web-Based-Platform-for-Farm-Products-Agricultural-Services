import { NextResponse } from "next/server"
import bcrypt from "bcryptjs"
import { getDb } from "@/lib/mongodb"
import { createSession } from "@/lib/auth"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const name = String(body.name || "").trim()
    const email = String(body.email || "").trim().toLowerCase()
    const phone = String(body.phone || "").trim()
    const password = String(body.password || "")

    if (!name || !email || !password) {
      return NextResponse.json(
        { error: "Name, email and password are required." },
        { status: 400 }
      )
    }

    if (name.length < 2) {
      return NextResponse.json({ error: "Please enter your full name." }, { status: 400 })
    }

    if (!/^\S+@\S+\.\S+$/.test(email)) {
      return NextResponse.json({ error: "Please enter a valid email address." }, { status: 400 })
    }

    if (password.length < 8) {
      return NextResponse.json(
        { error: "Password must contain at least 8 characters." },
        { status: 400 }
      )
    }

    const db = await getDb()
    const users = db.collection("users")

    const existingUser = await users.findOne({ email })
    if (existingUser) {
      return NextResponse.json(
        { error: "An account with this email already exists. Please log in." },
        { status: 409 }
      )
    }

    const passwordHash = await bcrypt.hash(password, 12)

    const result = await users.insertOne({
      name,
      email,
      ...(phone ? { phone } : {}),
      passwordHash,
      createdAt: new Date(),
      updatedAt: new Date(),
    })

    await createSession(result.insertedId.toString())

    return NextResponse.json(
      {
        message: "Account created successfully.",
        user: { id: result.insertedId.toString(), name, email, phone },
      },
      { status: 201 }
    )
  } catch (error) {
    console.error("Signup error:", error)
    return NextResponse.json(
      { error: "Unable to create your account right now." },
      { status: 500 }
    )
  }
}
