import { NextResponse } from "next/server"
import { deleteCurrentSession } from "@/lib/auth"

export async function POST() {
  try {
    await deleteCurrentSession()
    return NextResponse.json({ message: "Logged out successfully." })
  } catch (error) {
    console.error("Logout error:", error)
    return NextResponse.json({ error: "Unable to log out right now." }, { status: 500 })
  }
}
