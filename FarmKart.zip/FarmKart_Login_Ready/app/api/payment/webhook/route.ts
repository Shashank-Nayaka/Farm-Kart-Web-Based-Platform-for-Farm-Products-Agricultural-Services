import { NextResponse } from "next/server"
import crypto from "node:crypto"
import { getDb } from "@/lib/mongodb"

export async function POST(request: Request) {
  try {
    const secret = process.env.RAZORPAY_WEBHOOK_SECRET
    const signature = request.headers.get("x-razorpay-signature")
    if (!secret || !signature) return NextResponse.json({ error: "Missing webhook configuration." }, { status: 400 })

    const rawBody = await request.text()
    const expected = crypto.createHmac("sha256", secret).update(rawBody).digest("hex")
    const valid = expected.length === signature.length && crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature))
    if (!valid) return NextResponse.json({ error: "Invalid webhook signature." }, { status: 400 })

    const event = JSON.parse(rawBody)
    if (event.event === "payment.captured" || event.event === "order.paid") {
      const payment = event.payload?.payment?.entity
      const order = event.payload?.order?.entity
      const razorpayOrderId = payment?.order_id || order?.id
      const razorpayPaymentId = payment?.id
      if (razorpayOrderId) {
        const db = await getDb()
        const paymentOrder = await db.collection("payment_orders").findOne({ razorpayOrderId })
        if (paymentOrder && paymentOrder.status !== "paid") {
          await db.collection("payment_orders").updateOne(
            { _id: paymentOrder._id },
            { $set: { status: "paid", razorpayPaymentId, updatedAt: new Date() } },
          )

          const existing = await db.collection("orders").findOne({ appOrderId: paymentOrder.appOrderId })
          if (!existing && paymentOrder.userId) {
            await db.collection("orders").insertOne({
              appOrderId: paymentOrder.appOrderId,
              type: paymentOrder.type,
              userId: paymentOrder.userId,
              items: paymentOrder.details.items,
              total: paymentOrder.amountRupees,
              status: "ordered",
              date: new Date().toISOString().split("T")[0],
              vehicleName: paymentOrder.details.vehicleName,
              bookingDate: paymentOrder.details.bookingDate,
              timeSlot: paymentOrder.details.timeSlot,
              durationType: paymentOrder.details.durationType,
              hours: paymentOrder.details.hours,
              location: paymentOrder.details.location,
              payment: { status: "paid", method: "Razorpay", razorpayPaymentId, razorpayOrderId, paidAt: new Date() },
              createdAt: new Date(),
              updatedAt: new Date(),
            })
          }
        }
      }
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error("Razorpay webhook error:", error)
    return NextResponse.json({ error: "Webhook processing failed." }, { status: 500 })
  }
}
