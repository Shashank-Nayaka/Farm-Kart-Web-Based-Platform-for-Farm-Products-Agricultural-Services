import { NextResponse } from "next/server"
import { ObjectId } from "mongodb"
import { getCurrentUser } from "@/lib/auth"
import { getDb } from "@/lib/mongodb"
import { products, vehicles, timeSlots } from "@/lib/data"

function getRazorpayAuth() {
  const keyId = process.env.RAZORPAY_KEY_ID
  const keySecret = process.env.RAZORPAY_KEY_SECRET
  if (!keyId || !keySecret) throw new Error("Razorpay API keys are missing in .env.local")
  return { keyId, keySecret }
}

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ error: "Please log in before making a payment." }, { status: 401 })

    const body = await request.json()
    const type = body.type as "product" | "vehicle"

    let amountRupees = 0
    let details: Record<string, unknown> = {}
    const appOrderId = `${type === "product" ? "ORD" : "BK"}-${Date.now().toString(36).toUpperCase()}`

    if (type === "product") {
      const rawItems = Array.isArray(body.items) ? body.items : []
      if (!rawItems.length) return NextResponse.json({ error: "Your cart is empty." }, { status: 400 })

      const safeItems = rawItems.map((item: { productId: string; quantity: number }) => {
        const product = products.find((p) => p.id === item.productId)
        const quantity = Number(item.quantity)
        if (!product || !product.inStock || !Number.isInteger(quantity) || quantity < 1 || quantity > 100) {
          throw new Error("Invalid product or quantity.")
        }
        return { productId: product.id, name: product.name, quantity, price: product.price }
      })

      amountRupees = safeItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
      details = { items: safeItems }
    } else if (type === "vehicle") {
      const vehicle = vehicles.find((v) => v.id === body.vehicleId)
      const slot = timeSlots.find((s) => s.id === body.timeSlot)
      const durationType = body.durationType === "hourly" ? "hourly" : "daily"
      const hours = Number(body.hours || 1)

      if (!vehicle || !vehicle.available || !slot) return NextResponse.json({ error: "Invalid vehicle or time slot." }, { status: 400 })
      if (!body.bookingDate || !body.location?.trim()) return NextResponse.json({ error: "Booking date and farm location are required." }, { status: 400 })
      if (durationType === "hourly" && (!Number.isInteger(hours) || hours < 1 || hours > 12)) return NextResponse.json({ error: "Choose between 1 and 12 hours." }, { status: 400 })

      amountRupees = durationType === "daily" ? vehicle.dailyRate : vehicle.hourlyRate * hours
      details = {
        vehicleId: vehicle.id,
        vehicleName: vehicle.name,
        bookingDate: String(body.bookingDate),
        timeSlot: `${slot.label} (${slot.time})`,
        durationType,
        hours: durationType === "hourly" ? hours : undefined,
        location: String(body.location).trim(),
        items: [{ name: vehicle.name, quantity: 1, price: amountRupees }],
      }
    } else {
      return NextResponse.json({ error: "Invalid payment type." }, { status: 400 })
    }

    if (amountRupees <= 0) return NextResponse.json({ error: "Invalid amount." }, { status: 400 })

    const { keyId, keySecret } = getRazorpayAuth()
    const razorpayResponse = await fetch("https://api.razorpay.com/v1/orders", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${Buffer.from(`${keyId}:${keySecret}`).toString("base64")}`,
      },
      body: JSON.stringify({
        amount: Math.round(amountRupees * 100),
        currency: "INR",
        receipt: appOrderId,
        notes: { userId: user.id, appOrderId, type },
        capture: "automatic",
      }),
    })

    const razorpayData = await razorpayResponse.json()
    if (!razorpayResponse.ok) {
      console.error("Razorpay order creation failed:", razorpayData)
      return NextResponse.json({ error: razorpayData?.error?.description || "Unable to start payment." }, { status: 502 })
    }

    const db = await getDb()
    await db.collection("payment_orders").insertOne({
      appOrderId,
      razorpayOrderId: razorpayData.id,
      userId: new ObjectId(user.id),
      type,
      amountRupees,
      currency: "INR",
      status: "created",
      details,
      createdAt: new Date(),
      updatedAt: new Date(),
    })

    return NextResponse.json({
      keyId,
      razorpayOrderId: razorpayData.id,
      amount: razorpayData.amount,
      currency: razorpayData.currency,
      appOrderId,
      name: user.name,
      email: user.email,
      phone: user.phone || "",
    })
  } catch (error) {
    console.error("Create payment order error:", error)
    return NextResponse.json({ error: error instanceof Error ? error.message : "Unable to start payment." }, { status: 500 })
  }
}
