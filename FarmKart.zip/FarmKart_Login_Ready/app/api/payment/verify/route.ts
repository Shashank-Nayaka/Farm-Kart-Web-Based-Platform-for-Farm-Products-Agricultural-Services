import { NextResponse } from "next/server"
import crypto from "node:crypto"
import { ObjectId } from "mongodb"
import { getCurrentUser } from "@/lib/auth"
import { getDb } from "@/lib/mongodb"

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ error: "Please log in before verifying payment." }, { status: 401 })

    const body = await request.json()
    const { razorpayPaymentId, razorpayOrderId, razorpaySignature } = body
    if (!razorpayPaymentId || !razorpayOrderId || !razorpaySignature) {
      return NextResponse.json({ error: "Payment verification details are incomplete." }, { status: 400 })
    }

    const keySecret = process.env.RAZORPAY_KEY_SECRET
    if (!keySecret) throw new Error("RAZORPAY_KEY_SECRET is missing in .env.local")

    const db = await getDb()
    const paymentOrder = await db.collection("payment_orders").findOne({
      razorpayOrderId,
      userId: new ObjectId(user.id),
    })

    if (!paymentOrder) return NextResponse.json({ error: "Payment order was not found." }, { status: 404 })
    if (paymentOrder.status === "paid") return NextResponse.json({ order: await db.collection("orders").findOne({ appOrderId: paymentOrder.appOrderId }) })

    const expected = crypto
      .createHmac("sha256", keySecret)
      .update(`${paymentOrder.razorpayOrderId}|${razorpayPaymentId}`)
      .digest("hex")

    const valid = expected.length === razorpaySignature.length && crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(razorpaySignature))
    if (!valid) return NextResponse.json({ error: "Payment signature verification failed." }, { status: 400 })

    const orderDocument = {
      appOrderId: paymentOrder.appOrderId,
      type: paymentOrder.type,
      userId: new ObjectId(user.id),
      items: paymentOrder.details.items,
      total: paymentOrder.amountRupees,
      status: "ordered",
      date: new Date().toISOString().split("T")[0],
      vehicleName: paymentOrder.details.vehicleName,
      bookingDate: paymentOrder.details.bookingDate,
      timeSlot: paymentOrder.details.timeSlot,
      durationType: paymentOrder.details.durationType,
      hours: paymentOrder.details.hours,
      location: paymentOrder.details.location,
      payment: {
        status: "paid",
        method: "Razorpay",
        razorpayPaymentId,
        razorpayOrderId,
        razorpaySignature,
        paidAt: new Date(),
      },
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    const existing = await db.collection("orders").findOne({ appOrderId: paymentOrder.appOrderId })
    if (!existing) await db.collection("orders").insertOne(orderDocument)

    await db.collection("payment_orders").updateOne(
      { _id: paymentOrder._id },
      { $set: { status: "paid", razorpayPaymentId, updatedAt: new Date() } },
    )

    return NextResponse.json({
      message: "Payment verified and order created.",
      order: {
        ...orderDocument,
        id: paymentOrder.appOrderId,
      },
    })
  } catch (error) {
    console.error("Payment verification error:", error)
    return NextResponse.json({ error: "Unable to verify payment." }, { status: 500 })
  }
}
