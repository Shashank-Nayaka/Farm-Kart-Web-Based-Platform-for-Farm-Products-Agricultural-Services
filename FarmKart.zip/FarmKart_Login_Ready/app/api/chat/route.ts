import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const userMessage = body.message;

    // Simple AI logic (you can replace later with OpenAI)
    let reply = "";

    if (userMessage.toLowerCase().includes("seed")) {
      reply = "We offer high-quality seeds for various crops 🌱";
    } else if (userMessage.toLowerCase().includes("fertilizer")) {
      reply = "You can find organic and chemical fertilizers in our store.";
    } else if (userMessage.toLowerCase().includes("tractor")) {
      reply = "Yes, you can rent tractors directly from FarmKart 🚜";
    } else {
      reply = "I'm here to help with farming supplies, equipment, and services!";
    }

    return NextResponse.json({ reply });
  } catch (error) {
    return NextResponse.json(
      { reply: "Something went wrong." },
      { status: 500 }
    );
  }
}