import Link from "next/link"
import Image from "next/image"
import {
  Sprout,
  FlaskConical,
  Wrench,
  Heart,
  ArrowRight,
  Truck,
  Star,
  Users,
  Package,
  ShieldCheck,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { products } from "@/lib/data"

const categoryCards = [
  {
    name: "Seeds & Plants",
    description: "Premium crop seeds & saplings",
    icon: Sprout,
    href: "/shop?category=seeds",
    color: "bg-primary/10 text-primary",
    borderColor: "border-primary/30 hover:border-primary",
  },
  {
    name: "Fertilizers & Pesticides",
    description: "Organic & chemical solutions",
    icon: FlaskConical,
    href: "/shop?category=fertilizers",
    color: "bg-secondary/10 text-secondary",
    borderColor: "border-secondary/30 hover:border-secondary",
  },
  {
    name: "Tools & Equipment",
    description: "Essential farming tools",
    icon: Wrench,
    href: "/shop?category=tools",
    color: "bg-accent/10 text-accent",
    borderColor: "border-accent/30 hover:border-accent",
  },
  {
    name: "Animal Feed & Care",
    description: "Livestock feed & vet supplies",
    icon: Heart,
    href: "/shop?category=animal-feed",
    color: "bg-destructive/10 text-destructive",
    borderColor: "border-destructive/30 hover:border-destructive",
  },
]

const stats = [
  { label: "Products Available", value: "500+", icon: Package },
  { label: "Farmers Served", value: "50,000+", icon: Users },
  { label: "Vehicles for Hire", value: "120+", icon: Truck },
  { label: "Quality Guaranteed", value: "100%", icon: ShieldCheck },
]

const categoryEmoji: Record<string, string> = {
  seeds: "\u{1F33E}",
  fertilizers: "\u{1F9EA}",
  tools: "\u{1F4A7}",
  "animal-feed": "\u{1F404}",
}

const categoryLabel: Record<string, string> = {
  seeds: "Seeds & Plants",
  fertilizers: "Fertilizers",
  tools: "Tools",
  "animal-feed": "Animal Feed",
}

const featuredProducts = products.filter((p) => p.featured)

export default function HomePage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/hero-farm.jpg"
            alt="Lush green Indian farmland at golden hour"
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-r from-foreground/80 via-foreground/60 to-transparent" />
        </div>
        <div className="relative mx-auto flex min-h-[520px] max-w-7xl items-center px-4 py-20 lg:px-8">
          <div className="max-w-xl">
            <Badge className="mb-4 bg-secondary text-secondary-foreground">
              Trusted by 50,000+ Farmers
            </Badge>
            <h1 className="text-balance text-4xl font-extrabold leading-tight text-background md:text-5xl lg:text-6xl">
              Everything Your Farm Needs
            </h1>
            <p className="mt-4 text-pretty text-lg leading-relaxed text-background/80">
              Shop premium seeds, fertilizers, tools, and animal feed. Book
              tractors, harvesters, and drones. All delivered to your farm.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/shop">
                <Button size="lg" className="text-base font-semibold">
                  Shop Now
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Link href="/vehicles">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-background/30 bg-background/10 text-base font-semibold text-background hover:bg-background/20 hover:text-background"
                >
                  <Truck className="mr-2 h-4 w-4" />
                  Book Vehicles
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="mx-auto w-full max-w-7xl px-4 py-16 lg:px-8">
        <div className="mb-8 text-center">
          <h2 className="text-2xl font-bold text-foreground md:text-3xl">
            Shop by Category
          </h2>
          <p className="mt-2 text-muted-foreground">
            Find exactly what your farm needs
          </p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {categoryCards.map((cat) => (
            <Link key={cat.name} href={cat.href}>
              <Card
                className={`group cursor-pointer border-2 transition-all hover:-translate-y-1 hover:shadow-lg ${cat.borderColor}`}
              >
                <CardContent className="flex flex-col items-center p-6 text-center">
                  <div
                    className={`mb-4 flex h-14 w-14 items-center justify-center rounded-xl ${cat.color}`}
                  >
                    <cat.icon className="h-7 w-7" />
                  </div>
                  <h3 className="text-base font-semibold text-foreground">
                    {cat.name}
                  </h3>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {cat.description}
                  </p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="bg-muted/50 py-16">
        <div className="mx-auto max-w-7xl px-4 lg:px-8">
          <div className="mb-8 flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-foreground md:text-3xl">
                Popular Products
              </h2>
              <p className="mt-1 text-muted-foreground">
                Bestsellers loved by farmers
              </p>
            </div>
            <Link href="/shop">
              <Button variant="outline">
                View All <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </Link>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {featuredProducts.map((product) => (
              <Card
                key={product.id}
                className="group overflow-hidden transition-all hover:-translate-y-1 hover:shadow-lg"
              >
                <CardContent className="p-5">
                  <div className="mb-4 flex h-32 items-center justify-center rounded-lg bg-muted/80">
                    <span
                      className="text-6xl"
                      role="img"
                      aria-label={product.name}
                    >
                      {categoryEmoji[product.category] || "\u{1F33F}"}
                    </span>
                  </div>
                  <Badge variant="secondary" className="mb-2 text-xs">
                    {categoryLabel[product.category] || product.category}
                  </Badge>
                  <h3 className="font-semibold text-foreground">
                    {product.name}
                  </h3>
                  <div className="mt-1 flex items-center gap-1">
                    <Star className="h-3.5 w-3.5 fill-secondary text-secondary" />
                    <span className="text-sm font-medium text-foreground">
                      {product.rating}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      ({product.reviews})
                    </span>
                  </div>
                  <div className="mt-3 flex items-baseline gap-1">
                    <span className="text-lg font-bold text-primary">
                      Rs {product.price}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {product.unit}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Vehicle Booking CTA */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/vehicles-cta.jpg"
            alt="Tractor on Indian farmland"
            fill
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-foreground/85 via-foreground/70 to-foreground/40" />
        </div>
        <div className="relative mx-auto flex max-w-7xl items-center px-4 py-20 lg:px-8">
          <div className="max-w-lg">
            <h2 className="text-balance text-3xl font-extrabold text-background md:text-4xl">
              Need a Tractor or Harvester?
            </h2>
            <p className="mt-4 text-pretty leading-relaxed text-background/80">
              Book farming vehicles by the hour or day. Tractors, combine
              harvesters, crushers, rotavators, and even sprayer drones -
              delivered to your farm gate.
            </p>
            <Link href="/vehicles" className="mt-6 inline-block">
              <Button
                size="lg"
                className="bg-secondary text-secondary-foreground hover:bg-secondary/90"
              >
                <Truck className="mr-2 h-5 w-5" />
                Browse Vehicles
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="mx-auto w-full max-w-7xl px-4 py-16 lg:px-8">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="flex flex-col items-center rounded-xl border bg-card p-6 text-center"
            >
              <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                <stat.icon className="h-6 w-6 text-primary" />
              </div>
              <span className="text-2xl font-extrabold text-foreground">
                {stat.value}
              </span>
              <span className="mt-1 text-sm text-muted-foreground">
                {stat.label}
              </span>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}
