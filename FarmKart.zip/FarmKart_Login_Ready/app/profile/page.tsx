"use client"

import { useState } from "react"
import { AuthGuard } from "@/components/auth-guard"
import {
  User,
  Phone,
  MapPin,
  Wheat,
  Ruler,
  ShoppingBag,
  IndianRupee,
  Truck,
  Edit3,
  Save,
  ClipboardList,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { useOrders } from "@/lib/store"
import { toast } from "sonner"

function ProfilePageContent() {
  const { orders } = useOrders()
  const [editing, setEditing] = useState(false)
  const [profile, setProfile] = useState({
    name: "SHASHANK NAYAKA",
    phone: "+91 70199 76355 ",
    village: "Davangere, Karnataka",
    farmSize: "12 acres",
    crops: "Wheat, Rice, Sugarcane",
  })
  const [editForm, setEditForm] = useState(profile)

  const totalOrders = orders.length
  const productOrders = orders.filter((o) => o.type === "product").length
  const vehicleBookings = orders.filter((o) => o.type === "vehicle").length
  const totalSpent = orders.reduce((sum, o) => sum + o.total, 0)

  const handleSave = () => {
    setProfile(editForm)
    setEditing(false)
    toast.success("Profile updated successfully!")
  }

  const handleCancel = () => {
    setEditForm(profile)
    setEditing(false)
  }

  const recentOrders = orders.slice(0, 5)

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 lg:px-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground">My Profile</h1>
        <p className="mt-1 text-muted-foreground">
          Manage your farm details and account settings
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Left Column - Profile Info */}
        <div className="flex flex-col gap-6 lg:col-span-2">
          {/* Profile Card */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5 text-primary" />
                  Farmer Details
                </CardTitle>
                {!editing ? (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setEditing(true)}
                  >
                    <Edit3 className="mr-1.5 h-3.5 w-3.5" />
                    Edit
                  </Button>
                ) : (
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={handleCancel}>
                      Cancel
                    </Button>
                    <Button size="sm" onClick={handleSave}>
                      <Save className="mr-1.5 h-3.5 w-3.5" />
                      Save
                    </Button>
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col gap-6 sm:flex-row">
                {/* Avatar */}
                <div className="flex flex-col items-center gap-2">
                  <Avatar className="h-24 w-24 border-4 border-primary/20">
                    <AvatarFallback className="bg-primary/10 text-2xl font-bold text-primary">
                      {profile.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <Badge variant="secondary" className="text-xs">
                    Verified Farmer
                  </Badge>
                </div>

                {/* Info / Edit Form */}
                <div className="flex-1">
                  {editing ? (
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div className="flex flex-col gap-1.5">
                        <Label htmlFor="name">Full Name</Label>
                        <Input
                          id="name"
                          value={editForm.name}
                          onChange={(e) =>
                            setEditForm({ ...editForm, name: e.target.value })
                          }
                        />
                      </div>
                      <div className="flex flex-col gap-1.5">
                        <Label htmlFor="phone">Phone</Label>
                        <Input
                          id="phone"
                          value={editForm.phone}
                          onChange={(e) =>
                            setEditForm({ ...editForm, phone: e.target.value })
                          }
                        />
                      </div>
                      <div className="flex flex-col gap-1.5 sm:col-span-2">
                        <Label htmlFor="village">Village / Address</Label>
                        <Input
                          id="village"
                          value={editForm.village}
                          onChange={(e) =>
                            setEditForm({
                              ...editForm,
                              village: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div className="flex flex-col gap-1.5">
                        <Label htmlFor="farmSize">Farm Size</Label>
                        <Input
                          id="farmSize"
                          value={editForm.farmSize}
                          onChange={(e) =>
                            setEditForm({
                              ...editForm,
                              farmSize: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div className="flex flex-col gap-1.5">
                        <Label htmlFor="crops">Main Crops</Label>
                        <Input
                          id="crops"
                          value={editForm.crops}
                          onChange={(e) =>
                            setEditForm({
                              ...editForm,
                              crops: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col gap-3">
                      <div>
                        <h3 className="text-xl font-bold text-foreground">
                          {profile.name}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          Member since January 2024
                        </p>
                      </div>
                      <div className="grid gap-2 sm:grid-cols-2">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Phone className="h-4 w-4 text-primary" />
                          {profile.phone}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <MapPin className="h-4 w-4 text-primary" />
                          {profile.village}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Ruler className="h-4 w-4 text-primary" />
                          Farm Size: {profile.farmSize}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Wheat className="h-4 w-4 text-primary" />
                          Crops: {profile.crops}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ClipboardList className="h-5 w-5 text-primary" />
                Recent Activity
              </CardTitle>
              <CardDescription>Your latest orders and bookings</CardDescription>
            </CardHeader>
            <CardContent>
              {recentOrders.length === 0 ? (
                <p className="py-8 text-center text-sm text-muted-foreground">
                  No recent activity
                </p>
              ) : (
                <div className="flex flex-col gap-3">
                  {recentOrders.map((order) => (
                    <div
                      key={order.id}
                      className="flex items-center justify-between rounded-lg border p-3"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`flex h-9 w-9 items-center justify-center rounded-lg ${
                            order.type === "product"
                              ? "bg-primary/10"
                              : "bg-secondary/10"
                          }`}
                        >
                          {order.type === "product" ? (
                            <ShoppingBag className="h-4 w-4 text-primary" />
                          ) : (
                            <Truck className="h-4 w-4 text-secondary" />
                          )}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-foreground">
                            {order.type === "vehicle"
                              ? order.vehicleName
                              : `${order.items.length} item${order.items.length > 1 ? "s" : ""}`}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {order.id} - {order.date}
                          </p>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-1">
                        <span className="text-sm font-semibold text-foreground">
                          Rs {order.total}
                        </span>
                        <Badge variant="outline" className="text-[10px] capitalize">
                          {order.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right Column - Stats */}
        <div className="flex flex-col gap-4">
          <Card>
            <CardContent className="flex flex-col items-center p-6 text-center">
              <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-xl bg-primary/10">
                <ShoppingBag className="h-7 w-7 text-primary" />
              </div>
              <span className="text-3xl font-extrabold text-foreground">
                {totalOrders}
              </span>
              <span className="text-sm text-muted-foreground">
                Total Orders
              </span>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center p-6 text-center">
              <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-xl bg-secondary/10">
                <IndianRupee className="h-7 w-7 text-secondary" />
              </div>
              <span className="text-3xl font-extrabold text-foreground">
                Rs {totalSpent.toLocaleString()}
              </span>
              <span className="text-sm text-muted-foreground">Total Spent</span>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center p-6 text-center">
              <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-xl bg-accent/10">
                <Truck className="h-7 w-7 text-accent" />
              </div>
              <span className="text-3xl font-extrabold text-foreground">
                {vehicleBookings}
              </span>
              <span className="text-sm text-muted-foreground">
                Vehicle Bookings
              </span>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-semibold">
                Saved Addresses
              </CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col gap-3">
              <div className="flex items-start gap-2 rounded-lg border p-3">
                <MapPin className="mt-0.5 h-4 w-4 text-primary" />
                <div>
                  <p className="text-sm font-medium text-foreground">
                    Farm Address
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Davanagere, Block SS layout, Karnataka
                    - 577003
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-2 rounded-lg border p-3">
                <MapPin className="mt-0.5 h-4 w-4 text-secondary" />
                <div>
                  <p className="text-sm font-medium text-foreground">
                    Home Address
                  </p>
                  <p className="text-xs text-muted-foreground">
                    42, PB Road, Davanagere, Karnataka - 577003
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}


export default function ProfilePage() {
  return (
    <AuthGuard>
      <ProfilePageContent />
    </AuthGuard>
  )
}
